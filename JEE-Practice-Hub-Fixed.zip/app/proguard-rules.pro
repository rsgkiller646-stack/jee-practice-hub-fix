# ProGuard rules for JEE Practice Hub
-keep class com.jee.practicehub.** { *; }
